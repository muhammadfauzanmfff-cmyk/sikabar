<?php
// Mulai sesi
session_start();

// Definisikan username dan password statis
$validUsername = 'admin';
$validPassword = 'password123';

// Cek apakah form login telah disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Validasi username dan password
    if ($username === $validUsername && $password === $validPassword) {
        // Jika valid, simpan informasi sesi dan arahkan ke dashboard
        $_SESSION['username'] = $username;
        header('Location: dasboard.php'); // Arahkan ke halaman dashboard
        exit;
    } else {
        // Jika tidak valid, tampilkan pesan error
        $error = 'Username atau password salah';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
    <style>
        body {
            font-family: "Poppins", sans-serif;
            background-color: #387f39;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-container {
            display: flex;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            height: 100vh;
            border-radius: 0;
            overflow: hidden;
        }

        .login-image {
            background-image: url("assets/images/image1.jpg");
            background-size: cover;
            background-position: center;
            width: 75%;
            height: 100%;
        }

        .login-form input::placeholder {
            color: #fff;
            font-weight: lighter;
        }

        .login-form {
            padding: 50px;
            background-color: #387f39;
            width: 50%;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .login-form h1 {
            color: #fff;
            margin-bottom: 30px;
            font-size: 24px;
            font-weight: bold;
        }

        .login-form p {
            color: #fff;
            margin-bottom: 10px;
            font-size: 15px;
            font-weight: normal;
        }

        .form-control {
            background-color: rgba(249, 235, 255, 0.15);
            margin-bottom: 20px;
            border: none;
            outline: none;
            padding: 10px;
            height: 45px;
            color: #fff;
            border-radius: 15px;
        }

        .form-control:focus {
            background-color: rgba(249, 235, 255, 0.15);
            color: #fff;
            border: none;
            outline: none;
            box-shadow: none;
        }

        .btn-login {
            background-color: #ffff;
            border: none;
            padding: 10px;
            width: 100%;
            color: #387f39;
            border-radius: 15px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 20px;
            font-weight: bold;
        }

        .btn-login:hover {
            opacity: 0.8;
        }

        .error {
            color: #dc3545;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-image"></div>
        <div class="login-form">
            <h1>Welcome!</h1>
            <p>Masukkan Username dan Password</p>
            <form action="login.php" method="POST">
                <input type="text" class="form-control" name="username" placeholder="Username" required>
                <input type="password" class="form-control" name="password" placeholder="Password" required>
                <button type="submit" class="btn-login">Login</button>
            </form>
            <?php
            if (isset($error)) {
                echo "<p class='error'>$error</p>";
            }
            ?>
        </div>
    </div>
</body>
</html>
