<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $kategori_permohonan = $_POST['kategori_permohonan'] ?? '';
    $identitas = $_POST['identitas'] ?? '';
    $instansi = $_POST['instansi'] ?? '';
    $nama = $_POST['nama'] ?? '';
    $alamat = $_POST['alamat'] ?? '';
    $pekerjaan = $_POST['pekerjaan'] ?? '';
    $no_handphone = $_POST['no_handphone'] ?? '';
    $email = $_POST['email'] ?? '';
    $rincian = $_POST['rincian'] ?? '';
    $tujuan = $_POST['tujuan'] ?? '';
    $cara_memperoleh = $_POST['cara_memperoleh'] ?? '';
    $cara_mendapatkan = $_POST['cara_mendapatkan'] ?? '';
    $konfirmasi = isset($_POST['konfirmasi']) ? 1 : 0;

    // Proses upload file
    $file_name = '';
    if (isset($_FILES['berkas']) && $_FILES['berkas']['error'] === UPLOAD_ERR_OK) {
        $file_name = $_FILES['berkas']['name'];
        $file_tmp = $_FILES['berkas']['tmp_name'];
        $file_size = $_FILES['berkas']['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['jpg', 'jpeg', 'png', 'pdf'];
        if (in_array($file_ext, $allowed_exts) && $file_size <= 5242880) {
            $upload_dir = 'uploads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true); // Membuat direktori jika belum ada
            }
            $file_path = $upload_dir . basename($file_name);
            if (move_uploaded_file($file_tmp, $file_path)) {
                // File berhasil di-upload
            } else {
                echo "Gagal meng-upload file.";
                exit;
            }
        } else {
            echo "Format file tidak valid atau ukuran file terlalu besar.";
            exit;
        }
    }

    // Query untuk memasukkan data ke database
    include 'db.php'; // Pastikan file ini berisi kode koneksi ke database

    if ($conn) {
        $sql = "INSERT INTO informasi_permohonan (
            kategori_permohonan, identitas, instansi, nama, alamat, pekerjaan, no_handphone, email,
            rincian, tujuan, cara_memperoleh, cara_mendapatkan, berkas, konfirmasi, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("ssssssssssssss", $kategori_permohonan, $identitas, $instansi, $nama, $alamat, $pekerjaan, $no_handphone, $email, $rincian, $tujuan, $cara_memperoleh, $cara_mendapatkan, $file_name, $konfirmasi);
            
            if ($stmt->execute()) {
                echo "Data berhasil disimpan.";
            } else {
                echo "Terjadi kesalahan: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Gagal mempersiapkan query: " . $conn->error;
        }

        $conn->close();
    } else {
        die("Koneksi database gagal.");
    }
} else {
    echo "Form harus dikirim dengan metode POST.";
}
?>
