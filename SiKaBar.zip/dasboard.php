<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sikabarnew_db"; // Replace with your actual database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetching data from the database
$info_query = "SELECT * FROM informasi_permohonan"; // Replace with your actual table name
$info_result = $conn->query($info_query);

if ($info_result === FALSE) {
    echo "Error: " . $conn->error;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/templatemo-scholar.css">
    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #ffff;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100%;
            background-color: #387f39;
            padding-top: 20px;
        }

        .sidebar h1 {
            padding: 5px 30px;
            text-decoration: none;
            font-size: 35px;
            color: white;
            display: block;
        }
        .sidebar a {
            padding: 15px 30px;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
            font-weight: bold;
        }

        .sidebar a:hover {
            background-color: #2e5d29;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
        }

        .header {
            font-size: 20px;
            text-transform: capitalize;
            padding: 20px;
            background-color: #387f39;
            color: white;
            text-align: center;
        }

        .content {
            margin-top: 20px;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            background-color: #f8f9fa;
        }

        .content h2 {
            margin-top: 0;
        }

        .btn-group {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .btn-check {
            position: absolute;
            opacity: 0;
        }

        .btn-outline-primary {
            display: inline-block;
            padding: 10px 20px;
            font-size: 14px;
            font-weight: 600;
            color: #387f39;
            background-color: transparent;
            border: 2px solid #387f39;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-outline-primary:hover {
            background-color: #387f39;
            color: white;
        }

        .btn-check:checked + .btn-outline-primary {
            background-color: #387f39;
            color: white;
            box-shadow: 0 4px 10px rgba(0, 123, 255, 0.2);
        }

        .btn-outline-primary:focus {
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        .content-sections {
            display: none;
        }

        .content-sections.active {
            display: block;
        }

        .table-wrapper {
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th {
            padding: 8px;
            text-align: center;
        }

        td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .status {
    text-align: center;
}

.status .status-indicator {
    display: inline-block;
    padding: 5px 15px;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    text-transform: uppercase;
    margin: 5px;
}

.status .status-success {
    background-color: #28a745; /* Green */
}

.status .status-pending {
    background-color: #ffc107; /* Yellow */
    color: #212529; /* Dark Text */
}

.status .status-failure {
    background-color: #dc3545; /* Red */
}

.form-group {
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
}

form select {
    border: 2px solid #ced4da;
    border-radius: 5px;
    padding: 5px 10px;
    font-size: 14px;
    background-color: white;
    cursor: pointer;
    transition: border-color 0.3s;
}

form select:focus {
    border-color: #387f39;
    outline: none;
}

.pagination {
    text-align: center;
}

.pagination button {
    background-color: #387f39;
    color: white;
    border: none;
    padding: 10px 20px;
    margin: 5px;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.pagination button:hover {
    background-color: #2e5d29;
}

.pagination button.active {
    background-color: #2e5d29;
}
    </style>
</head>
<body>
    <div class="sidebar">
        <h1>SiKaBar</h1>
        <a href="#dashboard">Dashboard</a>
        <a href="#users">Users</a>
        <a href="#settings">Settings</a>
        <a href="#reports">Reports</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="main-content">
        <div class="header">
            <h1>Admin SiKaBar</h1>
        </div>

        <div class="content">
            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                <input type="radio" class="btn-check" name="btnradio" id="btnradio1" autocomplete="off" checked>
                <label class="btn btn-outline-primary" for="btnradio1">Permintaan Informasi</label>
              
                <input type="radio" class="btn-check" name="btnradio" id="btnradio2" autocomplete="off">
                <label class="btn btn-outline-primary" for="btnradio2">Layanan Difabel</label>
              
                <input type="radio" class="btn-check" name="btnradio" id="btnradio3" autocomplete="off">
                <label class="btn btn-outline-primary" for="btnradio3">Permohonan Keberatan</label>
            </div>

            <div class="content-sections" id="info-content">
    <h2>Permintaan Informasi</h2>
    <div class="table-wrapper">
        <table id="permohonan">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Loop through the results and display them in the table
                if ($info_result->num_rows > 0) {
                    while ($row = $info_result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>';
                        echo '<details>';
                        echo '<summary>' . htmlspecialchars($row['nama']) . '</summary>';
                        echo '<p>Kategori Permohonan: ' . htmlspecialchars($row['kategori_permohonan']) . '</p>';
                        echo '<p>Nomor Identitas: ' . htmlspecialchars($row['nomor_identitas']) . '</p>';
                        echo '<p>Instansi Yang Dituju: ' . htmlspecialchars($row['instansi_yang_dituju']) . '</p>';
                        echo '<p>Alamat: ' . htmlspecialchars($row['alamat']) . '</p>';
                        echo '<p>Email: ' . htmlspecialchars($row['email']) . '</p>';
                        echo '<p>No. HP: ' . htmlspecialchars($row['no_hp']) . '</p>';
                        echo '<p>Pekerjaan: ' . htmlspecialchars($row['pekerjaan']) . '</p>';
                        echo '<p>Rincian Yang Dibutuhkan: ' . htmlspecialchars($row['rincian_dibutuhkan']) . '</p>';
                        echo '<p>Tujuan Pengajuan Informasi: ' . htmlspecialchars($row['tujuan_pengajuan']) . '</p>';
                        echo '<p>Cara Memperoleh Informasi: ' . htmlspecialchars($row['cara_memperoleh']) . '</p>';
                        echo '<p>Cara Mendapatkan Informasi: ' . htmlspecialchars($row['cara_mendapatkan']) . '</p>';
                        echo '<p>Upload Berkas Identitas, Surat Ijin Penelitian: ' . htmlspecialchars($row['upload_berkas']) . '</p>';
                        echo '</details>';
                        echo '</td>';
                        echo '<td class="status">';
                        echo '<div class="form-group">';
                        echo '<form action="/update_status" method="POST">';
                        echo '<select name="status" onchange="this.form.submit()">';
                        echo '<option value="berhasil" ' . ($row['status'] === 'berhasil' ? 'selected' : '') . '>Berhasil</option>';
                        echo '<option value="pending" ' . ($row['status'] === 'pending' ? 'selected' : '') . '>Pending</option>';
                        echo '<option value="gagal" ' . ($row['status'] === 'gagal' ? 'selected' : '') . '>Gagal</option>';
                        echo '</select>';
                        echo '</form>';
                        echo '</div>';
                        echo '</td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="2">No data found</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <div class="pagination">
        <button class="active">1</button>
        <button>2</button>
        <button>3</button>
    </div>
</div>


           <div class="content-sections" id="objection-content">
                <h2>Permohonan Keberatan</h2>
                <div class="table-wrapper">
                    <!-- Tabel Permohonan Keberatan -->
                    <table id="permohonan">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <details>
                                        <summary>Maria</summary>
                                        <p>Kategori Keberatan:</p>
                                        <p>Nomor Identitas:</p>
                                        <p>Instansi Yang Dituju:</p>
                                        <p>Alamat:</p>
                                        <p>Email: maria@example.com</p>
                                        <p>No. HP: 08123456789</p>
                                        <p>Pekerjaan:</p>
                                        <p>Rincian Yang Dibutuhkan:</p>
                                        <p>Tujuan Pengajuan Keberatan:</p>
                                        <p>Cara Memperoleh Keberatan:</p>
                                        <p>Cara Mendapatkan Keberatan:</p>
                                        <p>Upload Berkas Identitas, Surat Ijin Penelitian:</p>
                                    </details>
                                </td>
                                <td class="status">
                                    <div class="form-group">
                                        <form action="/update_status" method="POST">
                                            <select name="status" onchange="this.form.submit()">
                                                <option value="berhasil" selected>Berhasil</option>
                                                <option value="pending">Pending</option>
                                                <option value="gagal">Gagal</option>
                                            </select>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="pagination">
                    <button class="active">1</button>
                    <button>2</button>
                    <button>3</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const btnradio1 = document.getElementById('btnradio1');
        const btnradio2 = document.getElementById('btnradio2');
        const btnradio3 = document.getElementById('btnradio3');

        const infoContent = document.getElementById('info-content');
        const disabilityContent = document.getElementById('disability-content');
        const objectionContent = document.getElementById('objection-content');

        function updateContent() {
            infoContent.classList.toggle('active', btnradio1.checked);
            disabilityContent.classList.toggle('active', btnradio2.checked);
            objectionContent.classList.toggle('active', btnradio3.checked);
        }

        btnradio1.addEventListener('change', updateContent);
        btnradio2.addEventListener('change', updateContent);
        btnradio3.addEventListener('change', updateContent);

        // Initialize content visibility
        updateContent();
    </script>
</body>
</html>
